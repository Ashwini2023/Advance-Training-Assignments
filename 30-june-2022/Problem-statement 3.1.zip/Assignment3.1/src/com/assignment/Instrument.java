package com.assignment;

public abstract class Instrument {
	public abstract void play();
}
